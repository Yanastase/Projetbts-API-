<?php

namespace App\Controller;

use App\Entity\Employee;
use App\Repository\CategorieRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Serializer\SerializerInterface;

class CategorieController extends AbstractController
{
    #[Route('/categorie', name: 'app_categorie')]
    
    public function index(CategorieRepository $CategorieRepository, SerializerInterface $serializerInterface): JsonResponse
    {
        $CategorieList = $CategorieRepository->findAll();
        $jsonCategorieList = $serializerInterface->serialize($CategorieList, 'json');
        return new JsonResponse(
             $jsonCategorieList, Response::HTTP_OK, [], true


        );
    }
}
