<?php

namespace App\Controller;

use App\Entity\Employee;
use App\Repository\ArticleRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;
use Symfony\Component\Serializer\SerializerInterface;

class ArticleController extends AbstractController
{
    #[Route('/article', name: 'app_employee')]
    public function index(ArticleRepository $ArticleRepository, SerializerInterface $serializerInterface): JsonResponse
    {
        $ArticleList = $ArticleRepository->findAll();
        $jsonArticleList = $serializerInterface->serialize($ArticleList, 'json');
        return new JsonResponse(
             $jsonArticleList, Response::HTTP_OK, [], true


        );
    }
}